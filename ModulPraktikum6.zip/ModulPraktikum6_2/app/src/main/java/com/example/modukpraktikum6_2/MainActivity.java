package com.example.modukpraktikum6_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView txt1 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       txt1 = (TextView) findViewById(R.id.textView1);
    }

    public void menu1 (View view){
        Intent intent = new Intent(MainActivity.this, Main2Activity.class);
        intent.putExtra("data1", txt1.getText().toString());

        startActivity(intent);
    }
}

